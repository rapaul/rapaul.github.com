class JsonControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
