class SessionTests extends GroovyTestCase {

    void testSomething() {

    }
}
