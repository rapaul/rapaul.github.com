import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ItemControllerTest {
	
	private ItemController itemController;
	@Mock private ItemService itemService;
	private Map<String, Object> modelMap;
	
	@Before
	public void setUp() {
		itemController = new ItemController(itemService);
		modelMap = new HashMap<String, Object>();
	}
	
	@Test
	public void viewItem() throws Exception {
	  Item item = new Item(3, "My Item");
	  
	  when(itemService.getItem(3)).thenReturn(item);
	  String viewItem = itemController.viewItem(3, modelMap);
	  
	  assertEquals("viewItem", viewItem);
	  assertEquals(item, modelMap.get("item"));
	}
	
	@Test
	public void viewItemWithItemNotFoundException() throws Exception {
	  ItemNotFoundException exception = new ItemNotFoundException(3);
    when(itemService.getItem(3)).thenThrow(exception);
	  
	  String viewItem = itemController.viewItem(3, modelMap);
	  
	  assertEquals("redirect:/errorPage", viewItem);
	  assertEquals(exception, modelMap.get("exception"));
	}

}
