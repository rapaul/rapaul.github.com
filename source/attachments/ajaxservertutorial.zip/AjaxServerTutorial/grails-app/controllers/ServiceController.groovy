import grails.converters.*
import java.text.SimpleDateFormat
class ServiceController {
  
  SimpleDateFormat formatter = new SimpleDateFormat("dd MMM yyyy HH:mm:ss")

  def sessions = {
    def sessionInfo
    if (params.id != null) {
      def id = params.id.toInteger()
      sessionInfo = Session.getSession(id)
    } else {
      sessionInfo = Session.getSessions()
    }
    render sessionInfo as JSON
  }

  def time = {
    render formatter.format(new Date())
  }

  def addSession = {
    Session session = new Session()
    session.properties = params
    session.id = Session.getSessionMaxId()
    Session.addSession(session)
    render 'Added'
  }

}
