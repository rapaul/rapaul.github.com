class Session {

  String name
  String date
  String speaker

  static def sessions = [
    new Session(1, "Javascript + Ajax Basics", "30 Jan 2009 14:00", "Richard"),
    new Session(2, "Dojo (javascript framework)", "13 Feb 2009 14:00", "Richard"),
    new Session(3, "Unit Testing", "13 Feb 2009 14:00", "Richard")
  ]

  Session() {}

  Session(id, name, date, speaker) {
    this.id = id
    this.name = name
    this.date = date
    this.speaker = speaker
  }

  def static getSession(id) {
    for (session in sessions) {
      if (session.id == id) return session;
    }
  }

  def static getSessions() {
    return sessions
  }

  def static getSessionMaxId() {
    def i = 1
    for (session in sessions) {
      if (session.id > i) {
        i = session.id
      }
    }
    return i + 1
  }
  
  def static addSession(session) {
    sessions.add(session)
  }

}
