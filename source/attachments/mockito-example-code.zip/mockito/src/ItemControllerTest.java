import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ItemControllerTest {
	
	private ItemController itemController;
	@Mock private ItemService itemService;
	private Map<String, Object> modelMap;
	
	@Before
	public void setUp() {
		itemController = new ItemController(itemService);
		modelMap = new HashMap<String, Object>();
	}
	
	@Test
	public void testViewItem() throws Exception {
		Item item = new Item(1, "Item 1");
		when(itemService.getItem(item.getId())).thenReturn(item);
		
		String view = itemController.viewItem(item.getId(), modelMap);
		
		assertEquals(item, modelMap.get("item"));
		assertEquals("viewItem", view);
	}
	
	@Test
	public void testViewItemWithItemNotFoundException() throws Exception {
		ItemNotFoundException exception = new ItemNotFoundException(5);
		when(itemService.getItem(5)).thenThrow(exception);
		
		String view = itemController.viewItem(5, modelMap);
		
		assertEquals("redirect:/errorView", view);
		assertSame(exception, modelMap.get("exception"));
	}

	@Test
	public void testDeleteItem() throws Exception {
		String view = itemController.deleteItem(5);

		verify(itemService).deleteItem(5);
		assertEquals("redirect:/itemList", view);
	}

}
