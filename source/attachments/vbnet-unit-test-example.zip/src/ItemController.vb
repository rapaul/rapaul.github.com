Imports System.Collections.Generic

Public Class ItemController

    Private mItemService As IItemService

    Public Sub New(ByRef itemService As IItemService)
        mItemService = itemService
    End Sub

    Public Function ViewItem(ByVal id As Integer, ByRef model As Dictionary(Of String, Object)) As String
        Dim item As Item = mItemService.getItem(id)
        model("item") = item
        Return "viewItem"
    End Function

End Class
