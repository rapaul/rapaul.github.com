Public Class Item

    Private mName As String

    Public Sub New(ByVal name As String)
        mName = name
    End Sub

    Public Property Name() As String
        Get
            Return mName
        End Get
        Set(ByVal value As String)
            mName = value
        End Set
    End Property

End Class
