Public Interface IItemService

    Function getItem(ByVal id As Integer) As Item

End Interface