Imports NUnit.Framework
Imports Rhino.Mocks
Imports System.Collections.Generic


<TestFixture()> _
Public Class ItemControllerTest

    Private mItemController As ItemController
    Private mModel As Dictionary(Of String, Object)
    Private mItemService As IItemService
    Private mMocks As MockRepository

    <SetUp()> _
    Public Sub setup()
        mMocks = New MockRepository()
        mItemService = mMocks.StrictMock(Of IItemService)()
        mItemController = New ItemController(mItemService)
        mModel = New Dictionary(Of String, Object)()
    End Sub

    <Test()> _
    Public Sub viewItem()
        Dim item As Item = New Item("My Item")
        Expect.Call(mItemService.getItem(3)).Return(item)

        mMocks.ReplayAll()
        Dim view As String = mItemController.ViewItem(3, mModel)
        mMocks.VerifyAll()

        Assert.AreEqual("viewItem", view)
        Assert.AreEqual(item, mModel("item"))
    End Sub

End Class
